Just paste this at the root of the folder and click yes to make it replace steam.inf
MADE FOR BUILD 852_3
this is because the location on where the steam.inf is different in later versions
Root as in where the start of the folder is