Just paste this at the root of the folder
MADE FOR BUILD 841_3
Root as in where the start of the folder is / where it has a lot of portal2_###### stuff
for example C:\PortalArchives\841_3\*PASTE HERE*
if you see a second 841_3 inside of the first 841_3 go into that 